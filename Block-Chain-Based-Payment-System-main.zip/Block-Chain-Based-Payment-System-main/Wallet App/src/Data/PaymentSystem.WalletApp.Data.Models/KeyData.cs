﻿namespace PaymentSystem.WalletApp.Data.Models
{
    public class KeyData
    {
        public string Secret { get; set; }
    }
}
