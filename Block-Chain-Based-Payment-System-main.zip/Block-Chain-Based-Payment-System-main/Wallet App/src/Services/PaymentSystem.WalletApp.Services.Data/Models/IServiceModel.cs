﻿namespace PaymentSystem.WalletApp.Services.Data.Models
{
    public interface IServiceModel
    {
    }
}
