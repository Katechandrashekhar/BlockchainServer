﻿namespace PaymentSystem.WalletApp.Web.Infrastructure.Options
{
    public class SecretOptions
    {
        public string Key { get; set; }
    }
}
