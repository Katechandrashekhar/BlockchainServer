﻿namespace PaymentSystem.WalletApp.Web.ViewModels.Home.Index
{
    using System.Collections.Generic;

    public class IndexModel
    {
        public IEnumerable<IndexTestimonialModel> Testimonials { get; set; }
    }
}
