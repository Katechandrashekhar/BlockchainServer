﻿namespace PaymentSystem.WalletApp.Data.Models
{
    public enum CardType
    {
        Visa = 1,
        MasterCard = 2,
        MaestroCard = 3,
        AmericanExpress = 4,
        Discover = 5,
    }
}
