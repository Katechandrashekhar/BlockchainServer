﻿namespace PaymentSystem.WalletApp.Web.ViewModels.Accounts.Index
{
    using System.Collections.Generic;

    public class AccountsIndexVewModel
    {
        public IEnumerable<AccountIndexListingModel> Accounts { get; set; }
    }
}
