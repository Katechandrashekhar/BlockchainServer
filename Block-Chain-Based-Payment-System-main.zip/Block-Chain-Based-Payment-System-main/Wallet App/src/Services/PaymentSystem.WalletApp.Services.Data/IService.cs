﻿namespace PaymentSystem.WalletApp.Services.Data
{
    public interface IService
    {
    }
}
