﻿namespace PaymentSystem.WalletApp.Data.Models
{
    public class CardData
    {
        public string CardNumber { get; set; }

        public string CVV { get; set; }

        public string CardHolderName { get; set; }
    }
}
