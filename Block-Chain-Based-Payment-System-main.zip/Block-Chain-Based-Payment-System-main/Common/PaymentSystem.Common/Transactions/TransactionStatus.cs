﻿namespace PaymentSystem.Common.Transactions
{
    public enum TransactionStatus
    {
        Canceled = 1,
        Pending = 2,
        Completed = 3,
    }
}
