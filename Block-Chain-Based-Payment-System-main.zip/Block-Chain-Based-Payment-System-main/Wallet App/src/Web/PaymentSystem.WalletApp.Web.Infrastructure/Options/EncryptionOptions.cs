﻿namespace PaymentSystem.WalletApp.Web.Infrastructure.Options
{
    public class EncryptionOptions
    {
        public string Key { get; set; }
    }
}
