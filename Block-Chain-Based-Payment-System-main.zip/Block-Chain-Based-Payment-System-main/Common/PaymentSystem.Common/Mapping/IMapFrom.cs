﻿namespace PaymentSystem.Common.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapFrom<T>
    {
    }
}
