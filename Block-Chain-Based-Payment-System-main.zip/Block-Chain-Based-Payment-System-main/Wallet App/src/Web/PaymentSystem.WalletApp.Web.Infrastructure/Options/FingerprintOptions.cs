﻿namespace PaymentSystem.WalletApp.Web.Infrastructure.Options
{
    public class FingerprintOptions
    {
        public string Key { get; set; }
    }
}
