﻿namespace PaymentSystem.WalletApp.Services.Data.Models.AccountsKeys
{
    public class StoreAccountKeyServiceModel
    {
        public string Address { get; set; }

        public string Secret { get; set; }
    }
}
