﻿namespace PaymentSystem.WalletApp.Data.Models
{
    public enum ActivityStatus
    {
        Pending = 1,
        Completed = 2,
        Canceled = 3,
    }
}
